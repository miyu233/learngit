// pages/otherpage/otherpage.js
Page({
  data:{
    name: '',
    phone: ''
  },
  onLoad: function(options){
    var name = wx.getStorageSync('name');
    var phone = wx.getStorageSync('phone');
    this.setData({name: name});
    this.setData({phone: phone});
  }
})
