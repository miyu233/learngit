// pages/index/index.js
Page({
  data:{
    name:'',
    phone:'',
    motto:'Hello World',
    displayPsg:'none',
    passage:'输入成功'
  },
  click: function(){
    wx.setStorageSync('name', this.data.name);
    wx.setStorageSync('phone', this.data.phone);
    this.setData({
      displayPsg: 'inline'
    });
    
  },
  clickIt: function(){
    wx.navigateTo({
      url: '../otherpage/otherpage'
    })
  },
  usrName: function(e){
    this.setData({
      name: e.detail.value
    })
  },
  phoneNum: function(e){
    this.setData({
      phone: e.detail.value
    })
  }
})
