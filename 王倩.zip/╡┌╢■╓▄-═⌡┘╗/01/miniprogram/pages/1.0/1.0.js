// miniprogram/pages/1.0/1.0.js
Page({

  data: {
    hidden: true
  },
  get_name: function(e){
    this.setData({
      name_:e.detail.value
    })
  },
  get_ph: function (e) {
    this.setData({
      phone_num: e.detail.value
    })
  },
  clickok: function (e) {
    this.setData({
      hidden: !this.data.hidden
    })
  },
  ok: function (e) {
    var that = this
    wx.navigateTo({
      url: '../1.1/1.1?name_Data=' +                that.data.name_ + '&phone_numData=' +that.data.phone_num
    })
  }
})