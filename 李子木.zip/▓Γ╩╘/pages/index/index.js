//index.js
//获取应用实例
const app = getApp()

Page({
  data:{
    name:'',
    phone:'',
    motto:''
  },
  clickButton:function(){
    wx.setStorageSync('name',this.data.name);
    wx.setStorageSync('phone', this.data.phone);
    wx.navigateTo({
      url: '../test/test'
    })
  },
  inputName:function(e){
    this.setData({
      name:e.detail.value
    })
  },
  inputPhone:function(e){
    this.setData({
      phone:e.detail.value
    })
  }
})