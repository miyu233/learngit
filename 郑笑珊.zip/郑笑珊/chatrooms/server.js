var http = require('http');
var fs = require('fs');
var path = require('path');
var mime = require('mime');
var cache = {};

// 1249224632@qq.com
function send404(response) {
	console.log('send404 is called.');
	response.writeHead(404, {'Content-Type': 'text/plain'});
	response.write('Error 404: resource not found.');
	response.end();
}

// 閿熺粨渚涢敓渚ョ》鎷烽敓鏂ゆ嫹閿熸嵎鍑ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹鍐欓敓鏂ゆ嫹閿熸枻鎷风‘閿熸枻鎷稨TTP澶撮敓鏂ゆ嫹鐒堕敓鏂ゆ嫹閿熸枻鎷烽敓渚ョ》鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹
function sendFile(response, filePath, fileContents) {
	console.log('sendFile is called. filePath=' +filePath);
	response.writeHead(
		200,
		{'Content-Type': mime.getType(path.basename(filePath))}
	);
	response.end(fileContents);
}

// 閿熺粨渚涢敓鏂ゆ嫹鎬侀敓渚ョ》鎷烽敓鏂ゆ嫹閿熸枻鎷�
function serveStatic(response, cache, absPath) {
	console.log('serveStatic is called. absPath=' +absPath);
  // 閿熸枻鎷烽敓鏂ゆ嫹鍕熼敓鏂ゆ嫹娆犵獣鎹嶉敓鏂ゆ嫹閿熸枻鎷疯瘱閿熸枻鎷烽敓锟�
	if (cache[absPath]) {
    // 閿熸枻鎷烽敓鑺傝揪鎷烽敓鍙嚖鎷烽敓鏂ゆ嫹閿熶茎纭锋嫹
		sendFile(response, absPath, cache[absPath]);
	} else {
    // 閿熸枻鎷烽敓鏂ゆ嫹鍕熼敓鏂ゆ嫹娆犻敓鏂ゆ嫹閿熸枻鎷�
		fs.exists(absPath, function(exists) {
			if (exists) {
        // 閿熸枻鎷风‖閿熸枻鎷烽敓鍙鎷峰彇閿熶茎纭锋嫹
				fs.readFile(absPath, function(err, data) {
					if (err) {
						send404(response);
					} else {
						cache[absPath] = data;
            // 閿熸枻鎷风‖閿熸枻鎷烽敓鍙鎷峰彇閿熶茎纭锋嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷�
						sendFile(response, absPath, data);
					}
				});
			} else {
        // 閿熶茎纭锋嫹閿熸枻鎷烽敓鏂ゆ嫹閿熻妭锝忔嫹閿熸枻鎷烽敓鏂ゆ嫹HTTP 404閿熸枻鎷烽敓鏂ゆ嫹
				send404(response);
			}
		});
	}
}

// 閿熸枻鎷烽敓鏂ゆ嫹HTTP閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷�
var server = http.createServer(function(request, response) {
	var filePath = false;
	
	if (request.url == '/') {
    // 纭敓鏂ゆ嫹閿熸枻鎷烽敓鎴鎷烽粯閿熸枻鎷稨TML閿熶茎纭锋嫹
		filePath = 'public/index.html';
	} else {
    // 閿熸枻鎷稶RL璺敓鏂ゆ嫹杞负閿熶茎纭锋嫹閿熸枻鎷烽敓鏂ゆ嫹閿熼摪鍑ゆ嫹閿燂拷
		filePath = 'public' + request.url;
	}
	var absPath = './' + filePath;
  // 閿熸枻鎷烽敓鎴拝鎷锋€侀敓渚ョ》鎷�
	serveStatic(response, cache, absPath);
});

// 閿熸枻鎷烽敓鏂ゆ嫹HTTP閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷�
server.listen(2333, function() {
	console.log("Server listening on port 2333.");
});

var chatServer = require('./lib/chat_server');
chatServer.listen(server);

