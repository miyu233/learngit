//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    name:null,
    tel:null,
    text:""
  },
  //事件处理函数
  getName:function(e){
    this.setData({
      name:e.detail.value
    })
  },
  getTel:function(e){
    this.setData({
      tel:e.detail.value
    })
  },
  inputcheck:function(e){
    if (!this.data.name || !this.data.name){
      this.setData({
      text: "输入失败"
    })
    }
    else{
      
      this.setData({
      text: "输入成功"
    })
    }
  },
  navi:function(){
    wx.navigateTo({url: '/pages/newpage/newpage?name=' + this.data.name + '&tel=' + this.data.tel})
  },
  
})
