// pages/newpage/newpage.js
Page({
  data: {
    name : "",
    tel : ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      name : options.name,
      tel : options.tel
    })
  },
})